Aplikasi monitoring masa berakhir kontrak karyawan menggunakan codeigniter 3


-----------------aplikasi ini masih tahap perkembangan----------------------



fitur aplikasi:


-berisi crud data pegawai


-notifikasi ke email hrd dan kabid, ketika kontrak karyawan sebulan lagi berakhir
